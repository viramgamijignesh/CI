<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-tachometer" aria-hidden="true"></i> Integrations        
      </h1>
    </section>
    
    <section class="content">
        <div class="row">
            
            <!--- csv desing -->

            <div class="container" style="margin-top:50px">    
             <br>
             
             <?php if (isset($error)): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            <?php if ($this->session->flashdata('success') == TRUE): ?>
                <div class="alert alert-success"><?php echo $this->session->flashdata('success'); ?></div>
            <?php endif; ?>
             
            <h2>CI Addressbook Import</h2>
                <form method="post" action="<?php echo base_url() ?>csv/importcsv" enctype="multipart/form-data">
                    <input type="file" name="userfile" ><br><br>
                    <input type="submit" name="submit" value="UPLOAD" class="btn btn-primary">
                </form>
            
            <br><br>
            <table class="table table-striped table-hover table-bordered">
                <caption>Address Book List</caption>
                <thead>
                    <tr>
                        <th>listing_id</th>
                        <th>artist</th>
                        <th>title</th>
                        <th>label</th>
                        <th>catno</th>
                        <th>format</th>
                        <th>release_id</th>
                        <th>status</th>
                        <th>price</th>
                        <th>listed</th>
                        <th>comments</th>
                        <th>media_condition</th>
                        <th>sleeve_condition</th>
                        <th>accept_offer</th>
                        <th>external_id</th>
                        <th>weight</th>
                        <th>format_quantity</th>
                        <th>flat_shipping</th>
                        <th>location</th>
                    </tr>
                </thead>
                <tbody>
                    <?php                   
                    if ($addressbook == FALSE): ?>
                        <tr><td colspan="4">There are currently No Addresses</td></tr>
                    <?php else: ?>
                        <?php foreach ($addressbook as $row): ?>
                            <tr>
                                <td><?php echo $row['listing_id']; ?></td>
                                <td><?php echo $row['artist']; ?></td>
                                <td><?php echo $row['title']; ?></td>
                                <td><?php echo $row['label']; ?></td>
                                <td><?php echo $row['catno']; ?></td>
                                <td><?php echo $row['format']; ?></td>
                                <td><?php echo $row['release_id']; ?></td>
                                <td><?php echo $row['status']; ?></td>
                                <td><?php echo $row['price']; ?></td>
                                <td><?php echo $row['listed']; ?></td>
                                <td><?php echo $row['comments']; ?></td>
                                <td><?php echo $row['media_condition']; ?></td>
                                <td><?php echo $row['sleeve_condition']; ?></td>
                                <td><?php echo $row['accept_offer']; ?></td>
                                <td><?php echo $row['external_id']; ?></td>
                                <td><?php echo $row['weight']; ?></td>
                                <td><?php echo $row['format_quantity']; ?></td>
                                <td><?php echo $row['flat_shipping']; ?></td>
                                <td><?php echo $row['location']; ?></td>

                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

            <!-- csv desing end -->

        </div>
    </section>
</div>